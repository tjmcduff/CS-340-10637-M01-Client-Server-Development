from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username='aacuser', password='SNHU1234'):
        # Connection details
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 32402
        DB = 'AAC'
        COL = 'animals'
        
        # MongoDB URI
        URI = f"mongodb://{username}:{password}@{HOST}:{PORT}/?authSource=aac"
        
        # Connect to the database
        self.client = MongoClient(URI)
        self.database = self.client[DB]
        self.collection = self.database[COL]

    def create(self, data):
        """Insert a document into the collection"""
        if data is not None:
            result = self.collection.insert_one(data)
            return True if result.acknowledged else False
        else:
            raise Exception("Nothing to insert. Data is empty.")

    def read(self, search_criteria):
        """Query documents from the collection"""
        if search_criteria is not None:
            results = list(self.collection.find(search_criteria))
            return results
        else:
            raise Exception("Search criteria is empty.")